# Isla Dino Maldita

Juego web de un solo archivo (`index.html`). Cuentas y progreso guardados en Supabase.

## Base de datos (Supabase, ya creada)
- Proyecto: `tcvmjqbtaavchqzeimex` (us-east-1)
- Tablas `accounts` y `saves` con RLS activo. Nadie lee las tablas directamente.
- Funciones: `dino_register`, `dino_login`, `dino_save`. Las contraseñas se guardan con bcrypt.

## Publicar en Netlify (la forma más fácil)
1. Entra en https://app.netlify.com/drop (inicia sesión con tu cuenta de Netlify).
2. Arrastra la carpeta `isla-dino-maldita` a la página.
3. Netlify te da una dirección tipo `https://nombre-aleatorio.netlify.app`.
4. Para cambiar el nombre: **Site configuration → Change site name**.

## Actualizar
- Sustituye `index.html` y vuelve a arrastrar la carpeta a Netlify, o en el mismo sitio usa **Deploys → Drag and drop**.
- Las cuentas están en Supabase, así que no se pierden al actualizar.

## Notas
- El progreso se guarda en la nube cada pocos segundos tras jugar, y al cerrar la página.
- Los amigos, el correo y los regalos entre cuentas dependían del sistema anterior y pueden no sincronizarse todavía. El multijugador por salas (ntfy.sh) sigue funcionando.
- Admin: la cuenta ADMIN001 sigue siendo solo local.
